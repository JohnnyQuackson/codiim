import matplotlib.pyplot as plt

import torch



import os
import numpy as np

from PIL import Image

from torchvision.models import resnet18


from PIL import Image
from torchvision.transforms import transforms

def square_walker(big_image_name, step, device='cpu'):
    big_img = Image.open(big_image_name)
    x, y = big_img.size
    square_images = []
    for i in range(x - step + 1):
        sq_image = big_img.crop((i, 0, i + step, y - 1))
        square_images.append(sq_image)

    format = big_img.format
    for i, img in enumerate(square_images):
      img.save(f"quers/{i}_square.jpg", format)
    

    return img_prediction('quers', model, device)

def image_transformer(img_names):
  image_objs = [] # Я не знаю, как сделать тот же функционал с np.array
  data = []
  preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )])

  
  for img_name in img_names:
    img = Image.open(img_name)
  
    img_preprocessed = preprocess(img)
  
    batch_img_tensor = torch.unsqueeze(img_preprocessed, 0)
    data.append(batch_img_tensor)
    #img = img.convert('L').convert('RGB').resize((256, 256))
  
    #convert_tensor = transforms.ToTensor()
    #image_obj = convert_tensor(img)
    #image_objs.append(image_obj)
    #image_objs.append(img)
  

  return torch.cat(data)

def img_prediction(directory,model, device = 'cpu'):
  img_names = [] # Я не знаю, как сделать тот же функционал с np.array
  for i, filename in enumerate(os.listdir(directory)):
    #print(i, filename)
    path = os.path.join(directory, filename)

    img_names.append(path)
  model.eval()

  batch = image_transformer(img_names)
  batch_ondevice = batch.to(device)

  probabilities = []
  letters = []
  prediction = model(batch_ondevice)
  print(prediction.shape)
  for vector in prediction:
    prediction_list = vector.tolist()
    letter = dictionary[prediction_list.index(max(prediction_list))]
    probability = torch.softmax(torch.Tensor(prediction_list), dim=0)
    letters.append(letter)
    probabilities.append(probability)

  return letters, probabilities

x, y = square_walker('/content/drive/MyDrive/Test letters/2.png')

for i, el in enumerate(y):
  listt = el.tolist()

  ind = listt.index(max(listt))
  dictionary[ind] += max(listt)
  #print(sum(listt))
  #print(max(listt), listt.index(max(listt)),x[i], entropy_calculation(listt))

  for key in dictionary.keys():
    dictionary[ind]/=len(dictionary[ind])

  s1 = dictionary