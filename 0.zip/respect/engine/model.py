from pathlib import Path

import random
import torch
from torchvision.models import EfficientNet_B5_Weights as base_model_weights
from PIL import Image
from torchvision.models import resnet18


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = resnet18(pretrained=True)
model.fc = torch.nn.Linear(512, 66)

model.load_state_dict(torch.load('14_w.pth', map_location=device))
model.eval()
transforms = base_model_weights.IMAGENET1K_V1.transforms()


def predict(path1: Path, path2: Path):
    #x = torch.argmax(model(transforms(Image.open(path1)).unsqueeze(0).to(device))).item()
    #y = torch.argmax(model(transforms(Image.open(path2)).unsqueeze(0).to(device))).item()

    return 'Просим прощения, модель недоработана'