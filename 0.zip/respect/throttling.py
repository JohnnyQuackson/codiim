from typing import Any, Awaitable, Callable
from dataclasses import dataclass
from time import time

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from aiogram.types import Message

from misc.const import timeout


@dataclass
class LastMessageData:
    user_id: int
    time: int


class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self):
        self.storage: dict[int, LastMessageData] = {}

    async def __call__(
        self, handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: Message, data: dict[str, Any]
    ) -> Any:
        user_id = event.from_user.id
        current_time = int(time())
    
        if current_time - self.storage.get(user_id, LastMessageData(0, 0)).time < timeout:
            return


        self.storage[user_id] = LastMessageData(
            user_id=user_id, time=current_time
        )

        return await handler(event, data)
