token = '6196124876:AAFT0Mte6zT_2aOCyOik1YcpbVyJYKxnOlc'
admin_ids = {1273366820}
timeout = 2
