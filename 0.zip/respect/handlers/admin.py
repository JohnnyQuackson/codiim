import os
from pathlib import Path
from sys import exit

from aiogram import Router, Bot
from aiogram.filters import Command, Text
from aiogram.types import Message, CallbackQuery

from handlers.filters import BotAdminMessageFilter, BotAdminCallbackFilter
from handlers import keyboards as kb


router = Router()
router.message.filter(BotAdminMessageFilter())
router.callback_query.filter(BotAdminCallbackFilter())


@router.message(Command(commands=["god"]))
async def admin_panel_command(message: Message):
    await message.answer("Good morning!", reply_markup=kb.InlineKeyboard(['everyone mes','stop ⛔'],['ever', 'shutdown']))

@router.callback_query(Text(text="ever"))
async def shutdown_query(callback: CallbackQuery, bot: Bot):
    await bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.message_id, text=callback.message.text,reply_markup=None)
    # users = os.listdir(Path('users'))
    # for id in users:
    #     await

@router.callback_query(Text(text="shutdown"))
async def shutdown_query(callback: CallbackQuery, bot: Bot):
    await bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.message_id, text=callback.message.text,reply_markup=None)
    await callback.answer()
    await callback.message.answer("Bye")
    exit()