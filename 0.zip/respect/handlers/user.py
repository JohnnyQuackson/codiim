import os


from pathlib import Path

from aiogram import Bot, Router, F
from aiogram.filters import Command, Text
from aiogram.types import Message, PhotoSize, CallbackQuery

from handlers import keyboards as kb
from engine.model import predict

router = Router()
@router.message(Command(commands=["start","help"]))
async def welcome_command(message: Message):
    if os.path.isdir(Path("users/" + str(message.chat.id))) == False:
        os.mkdir(Path("users/" + str(message.chat.id)))
    await message.answer("Привет! \nЯ могу сравнивать схожесть почерков 🔎📝", reply_markup=kb.InlineKeyboard(["Поехали!", "Инструкция"], ["0", "inst"]))

@router.callback_query(Text(text='inst'))
async def instructor(callback: CallbackQuery, bot: Bot):
    await bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.message_id, text=callback.message.text,reply_markup=None)
    await bot.send_message(chat_id=callback.message.chat.id, text='1. Нажмите на кнопку "Начнём!" ниже\n2. Дождитесь, пока вам ответит бот и отправте ему первое фото с рукописным текстом\n3. Дождитесь обратной связи от бота, отправьте второе фото\n4. Получите сообщение с результатом' ,
                           reply_markup=kb.InlineKeyboard(["Начнём!"],["0"])) 
    
@router.callback_query(Text(text='0'))
async def image(callback: CallbackQuery, bot: Bot):
    await bot.edit_message_text(chat_id=callback.message.chat.id, message_id=callback.message.message_id, text=callback.message.text,reply_markup=None)
    await callback.message.answer("Пожалуйста, отправьте первое фото 🖼", reply_markup=kb.ReplyKeyboardRemove())


@router.message(F.photo[-1].as_("photo"))
async def process_photo(message: Message, bot: Bot, photo: PhotoSize):
    user_photos = sorted(os.listdir(Path("users", str(message.chat.id))))
    photos_number = len(user_photos)

    photo_path = Path("users", str(message.chat.id), f"{photos_number}.jpg")

    await bot.download(photo, photo_path)
    if photos_number % 2 == 1:
        photo_path_ = Path("users", str(message.chat.id), f"{photos_number - 1}.jpg")
        print(photo_path_, photo_path)
        test1= predict(photo_path_,photo_path)
        #await message.answer("Схожесть почерков " + '{:.3f}'.format(test1), reply_markup=kb.ReplyKeyboard(['/help']))
        #await message.answer("Схожесть почерков " + '{:.3f}'.format(test2), reply_markup=kb.ReplyKeyboard(['/help']))

        await message.answer(str(test1), reply_markup=kb.ReplyKeyboard(['/help']))

    else:
        await message.answer("Пожалуйста, отправьте второе фото 🖼")

@router.message()
async def just_talk(message: Message, bot : Bot):
    text = message.text
    id = message.chat.id
    if text:
        await bot.send_message(chat_id=id, text='Извините, пока что я не могу на это ответить', reply_markup=kb.ReplyKeyboard(['/help']))
        #file = 'https://media.tenor.com/ydvzvVOMfr4AAAAd/toby-macgyver-toby.gif'
        #await bot.send_video(chat_id=id,video=file )
        

        

